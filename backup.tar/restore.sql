--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.3 (Debian 16.3-1.pgdg120+1)
-- Dumped by pg_dump version 16.3 (Debian 16.3-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE aala_robot;
--
-- Name: aala_robot; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE aala_robot WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE aala_robot OWNER TO postgres;

\connect aala_robot

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO postgres;

--
-- Name: companies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.companies (
    symbol character varying(100) NOT NULL,
    company_name character varying NOT NULL,
    code bigint
);


ALTER TABLE public.companies OWNER TO postgres;

--
-- Name: nsecompanies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.nsecompanies (
    symbol text,
    name_of_company text,
    series text,
    date_of_listing date,
    paid_up_value numeric,
    market_lot integer,
    isin_number text,
    face_value numeric
);


ALTER TABLE public.nsecompanies OWNER TO postgres;

--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alembic_version (version_num) FROM stdin;
\.
COPY public.alembic_version (version_num) FROM '$$PATH$$/3357.dat';

--
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.companies (symbol, company_name, code) FROM stdin;
\.
COPY public.companies (symbol, company_name, code) FROM '$$PATH$$/3358.dat';

--
-- Data for Name: nsecompanies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.nsecompanies (symbol, name_of_company, series, date_of_listing, paid_up_value, market_lot, isin_number, face_value) FROM stdin;
\.
COPY public.nsecompanies (symbol, name_of_company, series, date_of_listing, paid_up_value, market_lot, isin_number, face_value) FROM '$$PATH$$/3359.dat';

--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (symbol);


--
-- PostgreSQL database dump complete
--

